#######################################################
## setupData.R
##
## @authors Brantly Callaway and Tong Li
##
## build annual dataset of county-level
## unemployment rates used in main
## analysis
######################################################


## Load R packages
library(tidyr)
library(BMisc)


## Read in monthly unemployment data from
## Local Aread Unemployment Statistics Database
## from the BLS
undta <- read.table("lau-county-monthly", header=T, sep="\t")

################################################
## Format dataset
undta$series_id <- as.character(undta$series_id)
undta$value <- as.numeric(as.character(undta$value))
undta$fips <- substr(undta$series_id, 6, 10)
undta$state_fips <- substr(undta$series_id, 6, 7)
undta$county_fips <- substr(undta$series_id, 8, 10)
undta$var <- substr(undta$series_id, 20, 20)

undta$var <- as.factor(undta$var)
undta$var <- plyr::revalue(undta$var, c("3"="unem_rate", "4"="unem", "5"="emp", "6"="lf"))

undta <- subset(undta, select=-c(series_id, footnote_codes)) ## drop these columns, so can change from long format to wide format data

undta <- tidyr::spread(undta, var, value) ## change from long to wide format

undta$fips <- as.numeric(undta$fips)
undta$state_fips <- as.numeric(undta$state_fips)
undta$county_fips <- as.numeric(undta$county_fips)
#################################################


## Load timing of state level minimum wage increases
## This data comes from Dube, Lester, and Reich (2016)
library(foreign)

mw.series <- read.dta("DLR\ replication\ files/Data/MWseries_quarterly_Feb2013.dta")

fedmw <- aggregate(mw.series[,c("year", "quarter", "fed_mw")], by=list(mw.series$year, mw.series$quarter, mw.series$fed_mw),mean)
fedmw$plotq <- fedmw$year + (fedmw$quarter-1)*.25


#########################################################################
##assign a variable for first.treat and validstate (drop ones that aren't)
mw.series2 <- subset(mw.series, year %in% seq(1997,2007,1))
mw.series2 <- subset(mw.series2, !(year==2007 & quarter==3))
mw.series2 <- subset(mw.series2, !(year==2007 & quarter==4))
mw.series2 <- subset(mw.series2, !(year==1997 & quarter==1))
mw.series2 <- subset(mw.series2, !(year==1997 & quarter==2))
mw.series2 <- subset(mw.series2, !(year==1997 & quarter==3))
mw.series2 <- subset(mw.series2, !(state_name=="District of Columbia"))


omitted.states <- subset(mw.series2, year==1999 & quarter==2 & minwage > 5.15)$state_name
mw.series2 <- subset(mw.series2, !(state_name %in% omitted.states))
mw.series2 <- subset(mw.series2, quarter==1) ##may want to relax this later

mw.series2$alreadyassigned <- FALSE
mw.series2$first.treat <- 0
for (y in c(2000, 2002, 2004,2005,2006,2007)) { 
    cdta <- subset(mw.series2, year==y & quarter==1)
    cdta1 <- subset(mw.series2, year==(y-1) & quarter==1)
    this.treated <- cdta[(cdta$minwage > cdta$fed_mw) & (cdta1$minwage==cdta1$fed_mw) & cdta$alreadyassigned==FALSE,]$state_name
    mw.series2[mw.series2$state_name %in% this.treated,]$first.treat <- y
    mw.series2[mw.series2$state_name %in% this.treated,]$alreadyassigned <- TRUE
}
########################################################################


## merge the min wage series with the unemployment data
agg <- aggregate(mw.series2$first.treat, by=list(mw.series2$state_fips), mean)
colnames(agg) <- c("state_fips", "first.treat")
undta <- merge(x=undta, y=agg, by=c("state_fips"))


## finalize dataset
undta1 <- subset(undta, period=="M02") ## pick Feb.
undta1 <- subset(undta1, year>=2000 & year<=2007)
undta1 <- undta1[complete.cases(undta1),] ## don't think this drops anything
undta1$id <- undta1$fips
undta1 <- BMisc::makeBalancedPanel(undta1, "id", "year")
undta1 <- undta1[order(undta1$id, undta1$year),]
undta1 <- subset(undta1, first.treat==2007 | first.treat == 0)


#################################################################
## next, add covariates from 2000 county data book
cc.dta <- read.dta("us-counties-2000/DS0081/02896-0081-Data.dta")

cc.dta$county_name <- unlist(lapply(cc.dta$name, function(x) strsplit(x, ",")[[1]][1]))
##cc.dta$FIPS <- cc.dta$fips
cc.dta$msa <- 1*cc.dta$countype > 0 ## this isn't right!
cc.dta$pop <- cc.dta$b1_pop03
cc.dta$white <- cc.dta$b2_pop06
cc.dta$black <- cc.dta$b2_pop08
cc.dta$hs <- cc.dta$b5_edc06 - cc.dta$b5_edc08
cc.dta$col <- cc.dta$b5_edc08
cc.dta$medinc <- cc.dta$b5_inc01
cc.dta$pov <- cc.dta$b5_pov04
cc.dta$nssi <- cc.dta$b13_soc06

cc.dta <- cc.dta[,c("county_name", "stcode", "fips", "msa", "pop", "white", "black", "hs", "col", "medinc", "pov", "nssi")]
nrow(cc.dta)
cc.dta <- cc.dta[complete.cases(cc.dta),]
nrow(cc.dta)
##################################################################


## add state names to county characteristics dataset
cc.dta <- merge(cc.dta, data.frame(stcode=state.abb, region=state.region), by="stcode")


##################################################################
##merge min wage data and county characteristics
undta1 <- cbind(undta1, cc.dta[match(undta1$fips, cc.dta$fips),])

undta1$lpop <- log(undta1$pop)
undta1$lmedinc <- log(undta1$medinc)
undta1 <- droplevels(undta1)
undta1$unemprate1 <- (undta1$unem / undta1$lf)*100

undta1 <- subset(undta1, region != "Northeast") ## drop NE region
##################################################################



## only use observations that are "control" or first treated in 2007
dta <- subset(undta1, first.treat==2007 | first.treat==0) ##pick up data by year-treated group and control group
dta$treat <- 1*(dta$first.treat > 0)


dta <- dta[,c("unemprate1", "treat", "region", "black", "hs", "lpop", "pov", "col", "lmedinc", "medinc", "pop", "year", "stcode", "fips", "id")]
dta <- dta[complete.cases(dta),]
dta <- makeBalancedPanel(dta, "id", "year") ## this has slightly fewer rows than no covariates case

## some additional particular subsets of data
dta1 <- subset(dta, ((year >= 2005) & (year <= 2007)))
dta2 <- subset(dta, ((year >= 2004) & (year <= 2006)))
dta3 <- subset(dta, ((year >= 2003) & (year <= 2005)))


## save the main dataset
save(dta1, dta, file="mw.RData")

