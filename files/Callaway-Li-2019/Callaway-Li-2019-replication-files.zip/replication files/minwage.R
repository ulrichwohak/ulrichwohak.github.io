##################################################################
##
## minwage.R
##
## @authors Brantly Callaway and Tong Li
##
## Generates all results in "Quantile Treatment Effects in
## Difference in Differences Models with Panel Data"
##
##
###################################################################

## loads dta1 -- main dataset contains 2005-2007 data, and dta -- contains 2001-2007
load("mw.RData")

## path to save figures
figpath <- "../../paper/figures/min-wage/"

## install R packages used below
## qte package has `panel.qtet` method which does all the work using our approach
devtools::install_github("bcallaway11/qte")
devtools::install_github("bcallaway11/BMisc")
library(qte)
library(BMisc)

## formula for unconditional DID approach
formla <- unemprate1 ~ treat

## set quantiles to estimate results for
tau <- seq(.1,.9,.1)

## get QTE using uncondtional approach; these results are plotted in
## top panel of Figure 1
res1 <- panel.qtet(formla,
                  t=2007, tmin1=2006, tmin2=2005, tname="year", data=dta1,
                  idname="id", se=T, probs=tau, iters=1000)

## plot it (top panel of Figure 1)
ggqte(res1, ylim=c(-1,1), ybreaks=seq(-.8,.8,.2))


## formula for including covariates as in bottom panel of Figure 2
xformla <- ~ region*(lmedinc + lpop + I(lmedinc^2) + I(lpop^2) + I(lmedinc*lpop))

## results with first step estimation of propensity score as in bottom panel of Figure 2
xres1 <- panel.qtet(formla, xformla,
                  t=2007, tmin1=2006, tmin2=2005, tname="year", data=dta1,
                  idname="id", se=T, probs=tau, iters=1000,
                  pl=TRUE)

## plot it (bottom panel of Figure 2)
ggqte(xres1, ylim=c(-1,1), ybreaks=seq(-.8,.8,.2))


######################################################
## extra code to combine plots and generate Figure 1
## extra package for saving plots
library(gridExtra)

## x should be a list that contains
##  a qte object and the title
##  other things are just passed on to ggqte
ggqte_changingtitle <- function(x,...) {
    ggqte(qteobj=x$qteobj, main=x$main, ...)
}

pres1 <- list(qteobj=res1, main="Panel QTT, No Covs")
pxres1 <- list(qteobj=xres1, main="Panel QTT, Covs")

plots1a <- lapply(list(pres1, pxres1), ggqte_changingtitle, ylab="Cty Unem Rate", ylim=c(-.9,.9), ybreaks=c(-.8,-.6,-.4,-.2,0,.2,.4,.6,.8))

## Generates the actual Figure 1
do.call(gridExtra::grid.arrange, c(plots1a, list(ncol=1)))
##############################################################





######################################################################
## alternative approach (QDID and CIC)
## these results are plotted in Figure 2 of the supplementary appendix
q1 <- QDiD(formla, t=2007, tmin1=2006, tname="year",
     data=dta1, idname="id", panel=T, se=T, probs=tau)

c1 <- CiC(formla,  t=2007, tmin1=2006, tname="year",
          data=dta1, idname="id", panel=T, se=T, probs=tau)

xc1 <- CiC(formla, xformla, t=2007, tmin1=2006, tname="year",
           data=dta1, idname="id", panel=T, se=T, probs=tau)


pq1 <- list(qteobj=q1, main="QDID")
pc1 <- list(qteobj=c1, main="CIC, No Covs")
pxc1 <- list(qteobj=xc1, main="CIC, Covs")

plots1b <- lapply(list(pc1, pxc1, pq1), ggqte_changingtitle, ylab="Cty Unem Rate",
                  ylim=c(-.9,.9), ybreaks=c(-.8,-.6,-.4,-.2,0,.2,.4,.6,.8))

## Supplementary Appendix Figure 2
do.call(gridExtra::grid.arrange, c(plots1b, list(ncol=2)))
##
#####################################################################




#######################################################################
## Code for pre-tetsting (in supplementary appendix)
## choose finer grid of tau for pre-testing
tau <- seq(.1,.9,.02)

## function for computing results using all methods for a particular year
## returns a list of results
allResults <- function(lastyear) {
    thisdta <- subset(dta, year>=(lastyear-2) & year<=lastyear)
    res <- panel.qtet(formla,
                      t=lastyear, tmin1=(lastyear-1),
                      tmin2=(lastyear-2), tname="year", data=thisdta,
                       idname="id", se=T, probs=tau)
    xres <- panel.qtet(formla, xformla,
                       t=lastyear, tmin1=(lastyear-1),
                       tmin2=(lastyear-2), tname="year", data=thisdta,
                       idname="id", se=T, probs=tau)
    c <- CiC(formla,  t=lastyear, tmin1=(lastyear-1), tname="year",
              data=thisdta, idname="id", panel=T, se=T, probs=tau)
    q <- QDiD(formla, t=lastyear, tmin1=(lastyear-1), tname="year",
               data=thisdta, idname="id", panel=T, se=T, probs=tau)
    xc <- CiC(formla, xformla, t=lastyear, tmin1=(lastyear-1), tname="year",
              data=thisdta, idname="id", panel=T, se=T, probs=tau)
    return(list(res=list(list(qteobj=res, main="Panel QTT, No Covs"),
                list(qteobj=xres, main="Panel QTT, Covs"),
                list(qteobj=c, main="Change in Changes, No Covs"),
                list(qteobj=xc, main="Change in Changes, Covs"),
                list(qteobj=q, main="Quantile DID")), year=lastyear))
}

## function to plot all results for a particular year
## resultsyear is a list that contains a qteobj and title
makePrePlot <- function(resultsyear) {
    ry <- resultsyear
    py <- lapply(ry$res, ggqte_changingtitle, ylab="Cty Unem Rate", ylim=c(-1.9,1.9), ybreaks=c(-1.6,-1.2,-.8,-.4,0,.4,.8,1.2,1.6), setype="uniform")

    ##pdf(paste("pre-results-", ry$year, ".pdf", sep="")) ## uncomment this line to save plots
    do.call(gridExtra::grid.arrange,
            c(py, list(ncol=2,
                       main=grid::textGrob(as.character(ry$year),gp=grid::gpar(fontsize=20,font=3)))))
    ##dev.off()
}

## get all results for all years
## this is a bit slow, but speed may improve by running in parallel (just increase mc.cores)
preResults <- parallel::mclapply(seq(2006,2002,-1), allResults, mc.cores=1)

## make all plots in final section of supplementary appendix
## it may be helpful to save these by uncommenting lines in `makePrePlot` above
prePlots <- lapply(preResults, makePrePlot)
#############################################################################






####################################################################################
## Code for obtaining Kendall's Tau as in Figure 3 in main text
## get spearman's rho
## note: this code is not generic and runs specifically for our data...
getKendallsTau <- function(years, group="treated", iters=1000,
                            method="kendall", cluster=TRUE) {

    if (group == "treated") {
        undta2 <- subset(dta, treat==1) 
    } else {
        undta2 <- subset(dta, treat==0)
    }

    sp <- c()
    i <- 1
    for (y in years) {
        dy <- subset(undta2, year==y)$unemprate1 - subset(undta2, year==(y-1))$unemprate1
        ytmin1 <- subset(undta2, year==(y-1))$unemprate1
        sp[i] <- cor(dy, ytmin1, method=method)
        i <- i+1
    }

    ##now block bootstrap standard errors
    iters <- iters
    bb <- array(dim=c(length(years),iters))
    n <- nrow(subset(undta2, year==2006))
    
    for (i in 1:iters) {
        b <- sample(1:n, n, T)
        if (cluster) {
            n <- length(unique(undta2$stcode))
            bstates <- sample(unique(undta2$stcode), n, T)
            b <- unlist(lapply(bstates, function(x) { which(subset(undta2,year==2006)$stcode ==x) } ))
        } else { ## add non-cluster option 
            b <- sample(1:n, n, replace=T)
        }
        j <- 1
        sp1 <- c()
        for (y in years) {
            dy <- subset(undta2, year==y)[b,]$unemprate1 - subset(undta2, year==(y-1))[b,]$unemprate1
            ytmin1 <- subset(undta2, year==(y-1))[b,]$unemprate1
            sp1[j] <- cor(dy, ytmin1, method="spearman")
            j <- j+1
        }
        bb[,i] <- sp1
    }
    sds <- apply(bb, 1, sd)

    vmean <- apply(bb, 1, mean)
    vi <- apply(bb, 2, function(x) {x-vmean})
    V <- (1/iters)*vi%*%t(vi)

    ## set up matrix to make equal
    R <- matrix(nrow=(length(years)-1), ncol=length(years))
    l <- length(years)-1
    for (j in 1:l) {
        R[j,] <- c(1,rep(0,l))
        R[j,(j+1)] <- -1
    }
    ## R[1,] <- c(1,-1,0)
    ## R[2,] <- c(1,0,-1)
    
    thet <- as.matrix(sp)

    ## compute Wald Statistic to test if all equal
    W <- t(R%*%thet)%*%solve(R%*%V%*%t(R))%*%R%*%thet

    pval <- 1-pchisq(W, nrow(R)) 

    list(thet=thet, sds=sds, V=V, pval=pval, years=years)
}


## function to plot kendall's tau over time
ggkendallstau <- function(sp, sds, years, ylab="Kendall\'s Tau") {
    cmat <- data.frame(est=sp, sd=sds, year=years)
    p <- ggplot(cmat, aes(year, est,
       ymin=est - 1.96*sd,
       ymax=est + 1.96*sd)) +
    geom_point(aes(year, est), size=3, shape=21, fill="red") +
    geom_line(color="red", size=1) + 
    geom_errorbar(aes(year, est), size=.5, width=.15, color="red") +
    scale_y_continuous(ylab, limits=c(-1,1)) +
    scale_x_continuous('year', breaks=years) + 
    xlab("Year") +
        theme_bw()
    p
}

library(ggplot2)
spt <- getKendallsTau(seq(2001,2006,1), cluster=T, method="kendall")
##pdf(paste0(figpath,"treated-kendalls-tau.pdf"), width=7, height=5)
ggkendallstau(spt$thet, spt$sds, spt$years, ylab="Kendall\'s Tau")
##dev.off()

## unreported results for the untreated group instead
spu <- getKendallsTau(seq(2001,2007,1), group="untreated", method="kendall")
##pdf(paste0(figpath,"untreated-kendalls-tau.pdf"))
ggkendallstau(spu$thet, spu$sds, spu$years)
##dev.off()
#####################################################################    





##############################################################
## code for computing summary statistics as in Table 1
ssdta <- subset(dta, year==2007)

levels(ssdta$region)[levels(ssdta$region)=="North Central"] <- "NorthCentral"
ssdta <- droplevels(ssdta)
ssdta$unemprate2 <- subset(dta, year==2006)$unemprate1
ssdta$unemprate3 <- subset(dta, year==2005)$unemprate1

vars <- c("unemprate1", "unemprate2", "unemprate3", "region", "lmedinc", "lpop")

printmat <- do.call(rbind, lapply(vars, compareBinary, on="treat",
                                  dta=ssdta,
                                  report="both"))

printmat[,1:2] <- round(printmat[,1:2],2)
printmat[,3] <- round(printmat[,3],3)
printmat[,4] <- round(printmat[,4],2)
printmat <- apply(printmat, 2, as.character)


rownames <- c("Unem. Rate 2007", "Unem. Rate 2006", "Unem. Rate 2005", "South", "North-Central", "West", "Log Med. Inc.", "Log Pop.")

library(Hmisc)
caption <- "Summary Statistics"
ib <- "\\textit{Notes:} Summary statistics for counties by whether or not their minimum wage increased in Q1 of 2007 (treated) or not (untreated).  Unemployment rates are calculated using February unemployment and labor force estimates from the Local Area Unemployment Database.  Median income is the county's median income from 1997 and comes from the 2000 County Data Book.  Population is the county's population in 2000 and comes from the 2000 County Data Book. \\\\
  \\textit{Sources:} Local Area Unemployment Statistics Database from the BLS and 2000 County Data Book"
latex(printmat, rowname=rownames, colheads=c("Treated Counties", "Untreated Counties", "Diff", "P-val on Diff"), dcolumn=F, ctable=F, caption=caption, title="", col.just=c("c","c","c","c"), insert.bottom=ib, file="") ##file="summary-statistics.tex")
###############################################################



#########################################################################
## Implementation of Fan and Yu (2012) to construct bounds
## without any assumptions about the copula
## these results are in Figure 2 in the main text

## the `bounds` function is in the `qte` package
b <- bounds(formla, t=2007, tmin1=2006, tname="year",
       data=subset(dta1, year==2007 | year==2006),
       idname="id", probs=tau)

## plot the results
cmat <- data.frame(ub.qte=b$ub.qte, lb.qte=b$lb.qte, tau=b$probs)
##cmat <- reshape2::melt(cmat, id="tau")

##pdf(paste0(figpath,"bounds.pdf"), width=7, height=5)
ggplot(cmat, aes(x=tau)) +
    geom_line(aes(y=ub.qte)) +
    geom_line(aes(y=lb.qte)) +
    geom_point(aes(y=ub.qte)) +
    geom_point(aes(y=lb.qte), size=1.5) + 
    scale_y_continuous("Cty Unem Rate") +
    scale_x_continuous(breaks=c(.1,.3,.5,.7,.9), limits=c(0,1)) +
    theme_classic() + 
    theme(panel.border = element_rect(colour = 'black', size=1,
                                      fill=NA,
                                      linetype='solid'),
          plot.title = element_text(hjust=0.5))
##dev.off()
#########################################################################




########################################################################
## Estimates of QTT under conditional CSA using quantile regression
## as in Figure 1 in Supplementary Appendix
dta7 <- subset(dta, year==2007)
dta6 <- subset(dta, year==2006)
dta5 <- subset(dta, year==2005)
dta7 <- dta7[order(dta7$id),]
dta6 <- dta6[order(dta6$id),]
dta5 <- dta5[order(dta5$id),]
all(dta7$id == dta6$id) ## confirm all ids same and in right order
all(dta7$id == dta6$id)
dta7$dunemprate1 <- dta7$unemprate1 - dta6$unemprate1
dta6$dunemprate1 <- dta6$unemprate1 - dta5$unemprate1

library(quantreg)
u <- seq(.01,.99,.01)


## use QR to compute QTT
compute.condPQTT <- function(yname, idname, tname, t, tmin1, tmin2, treatname, xformla, data) {

    data <- BMisc::makeBalancedPanel(data, idname, tname)
    dta3 <- data[ data[,tname] == t,]
    dta2 <- data[ data[,tname] == tmin1,]
    dta1 <- data[ data[,tname] == tmin2,]
    dta3 <- dta3[order(dta3[,idname]),]
    dta2 <- dta2[order(dta2[,idname]),]
    dta1 <- dta1[order(dta1[,idname]),]

    dta3$y <- dta3[,yname]
    dta2$y <- dta2[,yname]
    dta1$y <- dta1[,yname]
    dta3$dy <- dta3$y - dta2$y
    dta2$dy <- dta2$y - dta1$y
    dta3$treat <- dta3[,treatname]
    dta2$treat <- dta2[,treatname]
    dta1$treat <- dta1[,treatname]

    yformla <- BMisc::toformula("y", BMisc::rhs.vars(xformla))
    dyformla <- BMisc::toformula("dy", BMisc::rhs.vars(xformla))
    
    dQR3 <- rq(dyformla, data=subset(dta3, treat==0), tau=u)
    dQR2 <- rq(dyformla, data=subset(dta2, treat==1), tau=u)
    QR2 <- rq(yformla, data=subset(dta2, treat==1), tau=u)
    QR1 <- rq(yformla, data=subset(dta1, treat==1), tau=u)

    n1 <- nrow(subset(dta3, treat==1))
    n0 <- nrow(subset(dta3, treat==0))
    QR1F <- predict(QR1, type="Fhat",stepfun=TRUE)
    F1 <- sapply(1:n1, function(i) QR1F[[i]](subset(dta1,treat==1)$y[i]))
    QR2Q <- predict(QR2, type="Qhat",stepfun=TRUE)
    Q2 <- sapply(1:n1, function(i) QR2Q[[i]](F1[i]))
    
    dQR2F <- predict(dQR2, type="Fhat", stepfun=TRUE)
    dF2 <- sapply(1:n1, function(i) dQR2F[[i]](subset(dta2, treat==1)$dy[i]))
    dQR3Q <- predict(dQR3, newdata=subset(dta3, treat==1), type="Qhat", stepfun=TRUE) ## predict for the treated guys even though estimate with the untreated guys
    dQ3 <- sapply(1:n1, function(i) dQR3Q[[i]](dF2[i]))
    
    yvals <- unique(dta3$y)
    yvals <- sort(yvals)
    Fy <- sapply(yvals, function(yy) mean(1*(dQ3+Q2 <= yy)))
    Fy <- makeDist(yvals,Fy)

    qtt <- quantile(subset(dta3, treat==1)$y, probs=tau, type=1) - quantile(Fy, probs=tau, type=1)

    qtt
}

## get point estimates
tau <- seq(.1,.9,.1)
cqtt <- compute.condPQTT("unemprate1", "id", "year", 2007, 2006, 2005, "treat", ~region*(lpop + lmedinc), data=dta)


## bootstrap standard errors
bootiters <- 1000
library(pbapply)
bootout <- pblapply(1:bootiters, function(b) {
    bdta <- blockBootSample(dta, "id")
    compute.condPQTT("unemprate1", "id", "year", 2007, 2006, 2005, "treat", ~region*(lpop + lmedinc), data=bdta)
    }, cl=4)

cqtt.se <- apply(simplify2array(bootout), 1, sd)

CQTT <- QTE(qte=cqtt, qte.se=cqtt.se,probs=tau)

## plot results
##pdf("qr-results.pdf")
ggqte(CQTT, ylim=c(-1,1), ybreaks=seq(-.8,.8,.2), ylab="Cty Unem Rate", main="Panel QTT, QR")
##dev.off()
####################################################################################

