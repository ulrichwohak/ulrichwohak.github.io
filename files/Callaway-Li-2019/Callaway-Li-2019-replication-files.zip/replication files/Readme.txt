Main Files:
 - minwage.R -- all main results generated using this file
 - mw.RData -- the dataset that is used in the paper; it contains county-level unemployment rates (from the Local Area Unemployment Statistics database from the Bureau of Labor Statistics), county characteristics (from the 2000 County Data Book), and information on the timing of state minimum wage policy changes (from Dube, Lester, and Reich (2016)).


Other Files:
 - setupData.R -- This not called from the minWage.R, but it is the code that we used to process the raw data.  These files are quite large and are not included with the replication material though the next part discusses how to obtain them.  


Obtaining Additional Raw Data Files:
 There are three raw data files that serve as inputs in setupData.R.  These are:
  - lau-county-monthly -- Tab delimited, county-level monthly unemployment rates from the BLS (the actual data file is here: https://download.bls.gov/pub/time.series/la/la.data.64.County or it can be accessed by clicking "Text Files" at: https://www.bls.gov/lau/data.htm and searching for the la.data.64.County file; note this is a large file)
  - MWseries_quarterly_Feb2013.dta -- dta file, available from the replication materials of Dube, Lester, and Reich (2016) at:  https://arindube.com/published-articles-and-book-chapters/
  - 02896-0081-Data.dta -- dta file; available from the Inter-university Consortium for Political and Social Research (ICPSR).  The raw data can be downloaded from:  https://www.icpsr.umich.edu/icpsrweb/ICPSR/studies/2896# (this is a large database that contains many files; the file that we use is DS0081/02896-0081-Data.dta)
